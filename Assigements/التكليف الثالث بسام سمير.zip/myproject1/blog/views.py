from django.shortcuts import render

# Create your views here.


def home(request):
    context = {
        'message': 'مرحبا بك في Django'
    }
    return render(request, 'index.html', context)

